<?php
$connect = mysql_connect("localhost", "root", "")or die("Could not connect to the Server");
mysql_select_db("php_forum")or die("Could not connect to the Database");;
?>