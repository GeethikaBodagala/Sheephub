# Website with PHP Login

*version 1.0*

## Description

Simple Website using PHP, HTML, CSS and JavaScript, providing information about mental health. This was successfully carried out during my undergraduate BSc Computing at Glasgow Caledonian University. 

#### Primary Objectives

- Implement a website to provide information regrading depression
- Features of the website inlcude forums in which people can create accounts
- Create a login System with PHP 
- Store member details in database
- Deployed Locally

All requirements above implememented successfully
